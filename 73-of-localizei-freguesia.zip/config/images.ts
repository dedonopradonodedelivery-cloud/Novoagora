export const IMAGE_BASES = {
  store: "https://source.unsplash.com/400x300/?store,",
  business: "https://source.unsplash.com/400x300/?business,",
};
